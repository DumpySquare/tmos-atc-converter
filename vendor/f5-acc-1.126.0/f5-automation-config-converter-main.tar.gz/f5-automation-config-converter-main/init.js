/**
 * Copyright 2023 F5, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

const getCliConfig = require('./src/preConverter/getCliConfig');

let isServer = false;
if (process.argv[2] === 'serve') {
    isServer = true;
}
const config = getCliConfig(isServer);
const main = require('./src/main').main;
const server = require('./src/server');

if (isServer) {
    return server();
}

return main(null, config);
